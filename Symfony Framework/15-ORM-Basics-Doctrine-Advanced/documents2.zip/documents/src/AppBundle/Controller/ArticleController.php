<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Article;
use AppBundle\Entity\Category;
use AppBundle\Form\ArticleType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;

class ArticleController extends Controller
{
  /**
   * @Route("/articles", name="articles_index")
   * @return \Symfony\Component\HttpFoundation\Response
   */
    public function indexAction()
    {
      $repo = $this->getDoctrine()->getRepository(Article::class);
      //$articles = $repo->findAllWithCategories();
      $articles = $repo->testPureSQL();

      return $this->render('articles/index.html.twig',['articles' => $articles]);
    }

  /**
   * @Route("/article/{id}", name="article_view", requirements={"id": "\d+"})
   * @param int $id
   * @return \Symfony\Component\HttpFoundation\Response
   */
    public function articleViewAction(int $id){
      $repo = $this->getDoctrine()->getRepository(Article::class);
      $article = $repo->find($id);

      if($article === null){
        throw $this->createNotFoundException('No article found');
      }
      return $this->render('articles/view.html.twig', ['article'=>$article]);
    }

  /**
   * @Route("/article2/{id}", name="article2_view")
   * @param Article $article
   * @return \Symfony\Component\HttpFoundation\Response
   */
  public function article2ViewAction(Article $article){

    if($article === null){
      throw $this->createNotFoundException('No article found');
    }
    return $this->render('articles/view.html.twig', ['article'=>$article]);
  }

  /**
   * @Route("/articles/create", name="articles_create")
   */
  public function articleCreateAction(Request $request){

    $article = new Article();
    $article->setColor('x');
    $article->setCreateDate(new \DateTime('now'));

    $form = $this->createForm(ArticleType::class,$article);
    $form->add('submit', SubmitType::class);
    $form->handleRequest($request);

    if($form->isSubmitted() && $form->isValid()){
      $em = $this->getDoctrine()->getManager();
      $em->persist($article);
      $em->flush();

      return $this->redirectToRoute('articles_index');
    }

    return $this->render('articles/create.html.twig',
      ['form'=>$form->createView()]
    );
  }

  public function articleCreateWithCategory(){
      $article = new Article();

      $category = new Category();
      $category->setName('new cat');

      $article->setCategory($category);

      $em = $this->getDoctrine()->getManager();

      $em->flush();


  }


  /**
   * @Route("/articles/update/{id}", name="article_update")
   * @param int $id
   * @return \Symfony\Component\HttpFoundation\Response
   */
  public function articleEditAction(int $id, Request $request){

    $em = $this->getDoctrine()->getManager();

    $repo = $em->getRepository(Article::class);
    $article = $repo->find($id);
    $article->setCreateDate(new \DateTime());

    $form = $this->createForm(ArticleType::class, $article);
    $form->add('submit', SubmitType::class);
    $form->handleRequest($request);

    if($form->isSubmitted() && $form->isValid()){

      $em->flush();

      return $this->redirectToRoute('articles_index');
    }

    return $this->render('articles/update.html.twig',
      ['form'=>$form->createView()]
    );
  }

  /**
   * @Route("/articles/delete/{id}", name="articles_delete")
   * @param int $id
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   */
  public function articleDeleteAction(int $id=null){

    $em = $this->getDoctrine()->getManager();
    $repo = $em->getRepository(Article::class);

    $article = $repo->find($id);


    if(null === $article){
      throw $this->createNotFoundException();
    }
    $em->remove($article);
    $em->flush();

    return $this->redirectToRoute('articles_index');

  }

}
