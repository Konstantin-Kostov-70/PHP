<?php

namespace AppBundle\Form;

use AppBundle\Entity\Category;
use AppBundle\Entity\Tag;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ArticleType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
          ->add('title',TextType::class,[
            'attr'=>['class'=>'shantav_class']
          ])
          ->add('body', TextareaType::class)
          ->add('slug')
          ->add('category', EntityType::class,[
              'class'=>Category::class,
              'choice_label'=>'name',
              'placeholder'=>'Choose a category'
              ])
          ->add('tags', EntityType::class,[
              'class' => Tag::class,
              'choice_label' => 'name',
              'placeholder' => 'Choose a tags',
              'multiple' => true,
              'expanded' => true
          ]);
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'AppBundle\Entity\Article'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'appbundle_article';
    }

    //<input
  //    type="text"
  //    id="appbundle_article_title"
  //    name="appbundle_article[title]"
  //    required="required"
  //    class="shantav_class" />
}
